# WaspOS
Its my own os
